Bendzz entry for TF Game Jam #1, June 12th 2022. (I ran out of time so it's very small)

This game was made for oculus VR headsets like the Quest 2.

All you can do is press right trigger or grip to "TF" her ears and tail. On PC that's W or E keys. (You can't look around on PC, sorry.)