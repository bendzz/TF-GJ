Bendzz entry for TF Game Jam #1, June 16th 2022. 
(Note: This build has 54.5 hours behind it (mostly on the model and blender bugs). It's way past the 25 hour time limit).


CONTROLS:
Oculus VR:
	-trigger (slowly) to pump up her TF
	-Joystick: Rotate slowly to arouse and distract her
	-grip to slowly undo her TF (just for fun, like to restart)

Keyboard:
	(Yes this is half assed. It's really meant for VR.)
	-W and E to pump her up (full pumps in the right order, or she'll startle)
	-Give her the D to arouse and distract her.
	-Q to undo TF

Exit:
	-Nuh uh.
